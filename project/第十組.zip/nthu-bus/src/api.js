function getRealtimeData() {}

function getSchedule() {}
